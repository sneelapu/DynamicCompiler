// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
   firebase: {
    apiKey: "AIzaSyDj13WXCor6uu7pc5JK0zkUFn0s_S2UFco",
    authDomain: "myfirstapp-a3414.firebaseapp.com",
    databaseURL: "https://myfirstapp-a3414.firebaseio.com",
    projectId: "myfirstapp-a3414",
    storageBucket: "myfirstapp-a3414.appspot.com",
    messagingSenderId: "200722937525"
},
 //apiURL :' https://afternoon-oasis-67133.herokuapp.com/'
apiURL:'http://localhost:8000/'
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
