import { Component, OnInit } from '@angular/core';
import usersList from './userList.json'
import { Router } from '@angular/router';
import { SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';
import * as _ from 'underscore';
import { GetUserInfoService } from '../services/get-user-info.service.js';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-admindashboard',
  templateUrl: './admindashboard.component.html',
  styleUrls: ['./admindashboard.component.css']
})
export class AdmindashboardComponent implements OnInit {
// ADD CHART OPTIONS. 
chartOptions = {
  responsive: true    // THIS WILL MAKE THE CHART RESPONSIVE (VISIBLE IN ANY DEVICE).
}

labels =  ['Python', 'Node.js', 'C#', 'Java'];
label=['Registered Users','Active Users']

// STATIC DATA FOR THE CHART IN JSON FORMAT.
chartData = [
  {
    label: 'Success rate',
    data: [210, 180, 480, 310, 550, 680,] ,
    fill:false
  },
 {
   label:'Total users',
   data:[1250,200,100,400,250,100],
   fill:false
 }
];

// CHART COLOR.
colors = [
 
 
  // { // 2nd Year.
  //   backgroundColor:'#e67e95',
  
  // },
]
  usersList: any;
  downloadUrl: any
  pager: { totalItems: number; currentPage: number; pageSize: number; totalPages: number; startPage: number; endPage: number; startIndex: number; endIndex: number; pages: any; };
  weboutput: SafeResourceUrl;
  userdata: any;
  userinfo: any;
  loader: boolean;
  Allusers: any;

  
  constructor(private router:Router,private  sanitizer: DomSanitizer,private aservice:GetUserInfoService) {
    // var urls = 'https://firebasestorage.googleapis.com/v0/b/me-portal.appspot.com/o/me_portal_dochub%2F2019%2FMay%2FLabsTeach_IBMWatsonStudio_%20BigData_MachineLearning_Oct5_2018_v1.0.pdf?alt=media&amp;token=8e10fac6-4228-45bc-8048-6ae1f40758e3';
    // // window.location.replace(this.weboutput);
    //  this.weboutput = sanitizer.bypassSecurityTrustResourceUrl(urls);
   }

  ngOnInit() {
   this.usersList=[]
   this.loader=true
    this.userdata=JSON.parse(localStorage.getItem('userdata'))
    this.pager = this.getPager(usersList.length, 1)
  
  
    this.getUserList(1)
  
// let url1 = 'assets/Images/200.gif';
//     this.downloadUrl = this.sanitizer.bypassSecurityTrustResourceUrl(url1);
  
  }

  setPage(page){
    this.loader=true
    this.usersList=[]
    this.getUserList(page)
  }
getUserList(page){
   this.usersList=[]
   
  this.aservice.UsersList( {page:page},this.userdata['token']).subscribe((resp)=>{
    console.log(resp)
    this.loader=false
    this.pager=this.getPager(resp['count'],page)
    this.usersList=resp['UsersList']
  })
}

  showUserprofile(user)
{
  console.log(user)
  this.userinfo=user
  if(user.resume.includes("https://firebasestorage.googleapis.com")){
    this.weboutput = this.sanitizer.bypassSecurityTrustResourceUrl(user.resume);
  }
  else{
    this.weboutput=''
  }
  
 // alert(cre)
 // this.router.navigate(['admin-nav/userprofile/:'+cre])
  
}
getPager(totalItems: number, currentPage: number = 1, pageSize: number = 5) {
  // calculate total pages
  console.log(totalItems)
  let totalPages = Math.ceil(totalItems / pageSize);
  //alert('total'+totalItems+"---"+totalPages)
  console.log(totalPages)
  console.log(currentPage)
  let startPage: number, endPage: number;
  if (totalPages < 6) {
    // less than 10 total pages so show all

    if (currentPage < 6) {
      startPage = 1;
      endPage = totalPages;
    }
  }
  else if (totalPages > 5 && totalPages <= 10) {
    console.log(currentPage)
    if (currentPage < 6) {
      startPage = 1;
      endPage = 5
    }
    else {
      startPage = currentPage - 1;
      endPage = totalPages;
    }
  } else {
    // more than 10 total pages so calculate start and end pages
    if (currentPage < 6) {
      startPage = 1;
      endPage = 5;
    } else if (currentPage + 4 > totalPages) {
      startPage = totalPages - 4;
      endPage = totalPages;
    } else {
      startPage = currentPage - 1;
      endPage = currentPage + 3;
    }
  }

  // calculate start and end item indexes
  let startIndex = (currentPage - 1) * pageSize;
  let endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

  // create an array of pages to ng-repeat in the pager control
  let pages = _.range(startPage, endPage + 1);

  // return object with all pager properties required by the view
  return {
    totalItems: totalItems,
    currentPage: currentPage,
    pageSize: pageSize,
    totalPages: totalPages,
    startPage: startPage,
    endPage: endPage,
    startIndex: startIndex,
    endIndex: endIndex,
    pages: pages
  };
}
}