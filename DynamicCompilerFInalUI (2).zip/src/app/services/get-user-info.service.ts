import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError, map } from 'rxjs/operators';
import{environment} from '../../environments/environment'

@Injectable({
  providedIn: 'root'
})
export class GetUserInfoService {


  constructor(private http: HttpClient) { }

  // Http Options
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }  

  // //Http Get method
  // getEmployees(reqbody) {
  //   return this.http.get(this.apiURL ,reqbody )
  //   .pipe(
  //     retry(1),
  //    // catchError(this.handleError)
  //   )
  // }
  AddUser(reqbody) {
    return this.http.post<any>(environment.apiURL+"Signup",  reqbody )
        .pipe(map(user => {
      
            return user;
        }));
}

Login(reqbody)
{
  return this.http.post<any>(environment.apiURL+"login", reqbody)
  .pipe(map(user=> {
    return user;
  }));
}
UsersList(page,token)
{
  console.log(token)
//   let headers = new Headers({'Content-Type': 'application/json'});  
 
//  headers.set("Authorization","Bearer"+reqbody);
//  var headers_object = new HttpHeaders();
//  headers_object.append('Content-Type', 'application/json');
//  headers_object.append("Authorization", "Bearer " + reqbody);
//  new HttpHeaders().set("Authorization", "Bearer " + t);
 var headers_object = new HttpHeaders().set("Authorization",   token);
 const httpOptions = {
   headers: headers_object
 };

  return this.http.post(environment.apiURL+"UsersList",page,httpOptions)
  .pipe(map(user=> {
    return user;
  }));
}
SchedulingTest(data,token)
{
  console.log(token)
//   let headers = new Headers({'Content-Type': 'application/json'});  
 
//  headers.set("Authorization","Bearer"+reqbody);
//  var headers_object = new HttpHeaders();
//  headers_object.append('Content-Type', 'application/json');
//  headers_object.append("Authorization", "Bearer " + reqbody);
//  new HttpHeaders().set("Authorization", "Bearer " + t);
 var headers_object = new HttpHeaders().set("Authorization",   token);
 const httpOptions = {
   headers: headers_object
 };

  return this.http.post("http://localhost:8000/scheduleTests",data,httpOptions)
  .pipe(map(user=> {
    return user;
  }));
}
createTests(data,token)
{
  console.log(token)
//   let headers = new Headers({'Content-Type': 'application/json'});  
 
//  headers.set("Authorization","Bearer"+reqbody);
//  var headers_object = new HttpHeaders();
//  headers_object.append('Content-Type', 'application/json');
//  headers_object.append("Authorization", "Bearer " + reqbody);
//  new HttpHeaders().set("Authorization", "Bearer " + t);
 var headers_object = new HttpHeaders().set("Authorization",   token);
 const httpOptions = {
   headers: headers_object
 };

  return this.http.post(environment.apiURL+"createTests",data,httpOptions)
  .pipe(map(user=> {
    return user;
  }));
}
AllUsersList(token){
  var headers_object = new HttpHeaders().set("Authorization",   token);
  const httpOptions = {
    headers: headers_object
  };
 
   return this.http.get(environment.apiURL+"Allusers",httpOptions)
   .pipe(map(user=> {
     return user;
   }));
}
}
