import { Injectable } from '@angular/core';
import { retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  constructor() { 

  }
  userLoggedin(){
    console.log(JSON.parse(localStorage.getItem('userdata')))
    if(JSON.parse(localStorage.getItem('userdata'))['token']!=null){
      return true
    }
    else{
      return false
    }
  }
}
