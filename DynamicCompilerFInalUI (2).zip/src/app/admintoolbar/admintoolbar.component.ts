import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import swal from 'sweetalert';
import * as XLSX from 'xlsx';
import { ThrowStmt } from '@angular/compiler';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { GetUserInfoService } from '../services/get-user-info.service';
import { duration } from 'moment';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateFRParserFormatt } from '../DateParser';

@Component({
  selector: 'app-admintoolbar',
  templateUrl: './admintoolbar.component.html',
  styleUrls: ['./admintoolbar.component.css'],
providers:[{ provide: NgbDateParserFormatter, useClass: NgbDateFRParserFormatt }]
})
export class AdmintoolbarComponent implements OnInit {
  allNotificationsLength: { notificationDescription: string; }[];
  model;
  usersdata: any;
  showHrRole: boolean;
  showadminRole: boolean;
  fileName: any;
  navtitle: string;
 
  questionsForm: FormGroup;
  question: any;
  questions: any;
  Allusers: any;
  scheduletestForm: FormGroup;
  willDownload = false;
  scheduletestFormSubmitted :boolean=false;
  fileupload:boolean=false;
  showUpload: boolean;
constructor(public _router: Router,private formbuilder:FormBuilder,private aservice:GetUserInfoService,private ngdate:NgbDateParserFormatter) {
    this.questionsForm = this.formbuilder.group({
      language:  ['', Validators.required],
     questionsnumber:[1, Validators.required],
      qfile:  '',
      questions: this.formbuilder.array([ this.createQuestion() ])
    });
    this.scheduletestForm = this.formbuilder.group({
      sdate: ['', Validators.required],
      stime: ['', Validators.required],
      etime: ['', Validators.required],
      language: ['null', Validators.required],
      questionsnumber:['null', Validators.required],
      query: ['', Validators.required],
      duration: ['', Validators.required],
      crefrom:['null',Validators.required],
      creto:['null',Validators.required]
    })
   }
   DisplayQuestions(event)
   {
// if(event.target.value=="Upload File"){
//   this.showUpload=true;
// }
// else{
//   this.showQuestions
// }
   }
   createQuestion(): FormGroup {
    return this.formbuilder.group({
      question: [''],
      expectedAnswer:['']
    
    });
  }
  quescountChanged(event){
    console.log(this.scheduletestForm)
    console.log(event.target.value)
    this.scheduletestForm.controls['duration'].patchValue(event.target.value*15)
    console.log(this.scheduletestForm)
  }
  addNewItem(): void {
    this.questions = this.questionsForm.get('questions') as FormArray;
    this.questions.push(this.createQuestion());
  }
  removeItem(){
    if(this.questions.value.length>1 && this.questions.value.length<6){
      this.questions.removeAt(this.questions.value.length - 1)
    }
   
  }
  onFileChange(ev) {
   
    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    const file = ev.target.files[0];
    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      const dataString = JSON.stringify(jsonData);
      console.log('dataString',dataString)
      document.getElementById('output').innerHTML = dataString.slice(0, 300).concat("...");
      this.setDownload(dataString);
    }
    reader.readAsBinaryString(file);
  }


  setDownload(data) {
    this.willDownload = true;
    setTimeout(() => {
      const el = document.querySelector("#download");
      el.setAttribute("href", `data:text/json;charset=utf-8,${encodeURIComponent(data)}`);
      el.setAttribute("download", 'xlsxtojson.json');
    }, 1000)
  }
  ngOnInit() {
    console.log(localStorage.getItem('userdata'))
    this.usersdata=JSON.parse(localStorage.getItem('userdata'))
    this.aservice.AllUsersList(this.usersdata['token']).subscribe((resp)=>{
      console.log(resp)
      this.Allusers=resp['UsersList']
      
    })
    this.showoptions()
  //   this.allNotificationsLength=[
  //     {
  //     notificationDescription:"test"
  //   },
  //   {
  //     notificationDescription:"test"
  //   },
  //   {
  //     notificationDescription:"test"
  //   },  {
  //     notificationDescription:"test"
  //   },  {
  //     notificationDescription:"test"
  //   }
  // ]

   }
  Logout()
{
  this._router.navigate(['login']);
}
scheduleTest(){
  this.scheduletestFormSubmitted=true
  console.log(this.scheduletestForm.value)
  let screenigdata={
    "screeningDate": this.ngdate.format(this.scheduletestForm.value.sdate),
    "starttime": this.scheduletestForm.value.stime,
    "endtime": this.scheduletestForm.value.etime,
    "language": this.scheduletestForm.value.language,
    "Questions": this.scheduletestForm.value.query,
    "Duration": this.scheduletestForm.value.duration,
    "crefrom": this.scheduletestForm.value.crefrom,
    "creto": this.scheduletestForm.value.creto,
    "createdby": this.usersdata['data'][0]['Username'],
    "score": 0,
    "status": ""
  }
  console.log(screenigdata)
   
  this.aservice.SchedulingTest(screenigdata,this.usersdata['token']).subscribe((resp)=>{
    console.log(resp)
   // this.Allusers=resp['UsersList']
   if(resp['success']){

    swal("","Scheduled Test Successfully","success")
   }
  else{
    swal("","Something went wrong","warning")
  }
    
  },(err)=>{
    swal("","Something went wrong","warning")
  })

}
uploadQuestions(){
  this.fileupload= true;
  console.log(this.usersdata['data'])
  console.log(this.usersdata['data'][0])
  let questiondata={
    "langugage":this.questionsForm.value.language,
    "questions":this.questionsForm.value.questions,
    "createdby":this.usersdata['data'][0]['Username']
  }
  console.log(questiondata)
  this.aservice.createTests(questiondata,this.usersdata['token']).subscribe((resp)=>{
    swal("","Uploaded Questions Successfully","success")
  },(err)=>{
    swal("","something went wrong .please,try again later","warning")
  })

}
showoptions(){
  console.log(this.usersdata['data'][0])
  console.log(this.usersdata['data'])
  if(this.usersdata['data'][0]['role']=="Hr"){
    this.showHrRole=true
    this.navtitle="Schedule a Test"
  }
  else  if(this.usersdata['data'][0]['role']=="Admin"){
    this.showadminRole=true
    this.navtitle="uploadQuestions"
  }
  
}
uploadFile(event){
this.fileName=event.target.files[0].name
}
}
