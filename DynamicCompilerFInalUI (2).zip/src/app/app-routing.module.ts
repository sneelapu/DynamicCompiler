import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AdmintoolbarComponent } from './admintoolbar/admintoolbar.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { TestComponent } from './test/test.component';
import { UserlistComponent } from './userlist/userlist.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { TaktestComponent } from './taktest/taktest.component';
import { AuthGuard } from './auth/auth.guard';

const routes: Routes = [
  {
    path:'',
    redirectTo:'/login',
    pathMatch:'full'
  },
{
  path:'login',
  component:LoginComponent
},
{
  path:'register',
  component:RegisterComponent
},
{
  path:'admin-nav',
  component:AdmintoolbarComponent,
  children:[
    { 
      path:'admindashboard',
      component:AdmindashboardComponent,
      canActivate: [AuthGuard]
     },
  {
       path:'test',
       component:TestComponent,
       canActivate: [AuthGuard]
  },
  {
    path:'userlist',
    component:UserlistComponent,
    canActivate: [AuthGuard]
  },
  {
    path:'userprofile/:number',
    component:UserProfileComponent,
    canActivate: [AuthGuard]
  },
  {
    path:'usertest',
    component:TaktestComponent,
    canActivate: [AuthGuard]
  }
   
  
  ]
  
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
