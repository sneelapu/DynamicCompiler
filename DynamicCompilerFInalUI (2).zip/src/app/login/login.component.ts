import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as roledata from './roles.json';
import { GetUserInfoService } from '../services/get-user-info.service.js';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  inputEmail: any;
  inputpass: any;
  msg: string;
  formsubmitted: boolean=false;

  constructor(private _router : Router, private login:GetUserInfoService) { }

  ngOnInit() {
    console.log(roledata);
  }

  
  btnclick() {
    this.formsubmitted=true
    this.msg='';
    if(this.inputEmail==''||this.inputpass==''||!this.inputEmail||!this.inputpass){
//this.msg="Username and Password are required"
    }
    else{

    
    let loginInfo = {
      "username": this.inputEmail,
      "password": this.inputpass
    }
    console.log(loginInfo);
    this.login.Login(loginInfo)

      .subscribe(
        data => {
          console.log(data)
          console.log(data['success'])
     //     console.log(data['data'][0]['role'])
          if (data['success'] == true) {
            if(data['data'][0]['role'] == "Hr" || data['data'][0]['role'] == "Admin"){
              this._router.navigate(['admin-nav/admindashboard'])
          localStorage.setItem('userdata',JSON.stringify(data))
            }
           else if (data['data'][0]['role'] == "user")
            {
              localStorage.setItem('userdata',JSON.stringify(data))
              this._router.navigate(['admin-nav/usertest'])
            }
          }
          
          else {
            this.formsubmitted=false
            this.msg = data['success']
          }
        },
        error => {
          // swal("","Something went wrong.please, try again","warning")
          console.log(error)

        });




      }
  }
}

