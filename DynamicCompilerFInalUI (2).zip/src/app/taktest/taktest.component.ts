
import { Component, OnInit , Output, Input, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { interval } from 'rxjs';
import { map } from 'rxjs/operators'
import * as qstns from './questions.json';
import { Subscription, Observable, timer } from 'rxjs';
import moment from 'moment';
import swal from 'sweetalert';

@Component({
  selector: 'app-taktest',
  templateUrl: './taktest.component.html',
  styleUrls: ['./taktest.component.css']
})
export class TaktestComponent implements OnInit {
//COde for timer
private subscription: Subscription;
@Output() TimerExpired: EventEmitter<any> = new EventEmitter<any>();
@Input() SearchDate: moment.Moment = moment();
@Input() ElapsTime: number = 3;
searchEndDate: moment.Moment;
remainingTime: number;
minutes: number;
seconds: number;
everySecond: Observable<number> = timer(0, 1000)
//
questionList: any;
showindex:number=0;

constructor(private ref: ChangeDetectorRef) { this.searchEndDate = this.SearchDate.add(this.ElapsTime, "minutes"); }

ngOnInit() {
//Code for timer
this.subscription = this.everySecond.subscribe((seconds) => {
var currentTime: moment.Moment = moment();
this.remainingTime = this.searchEndDate.diff(currentTime)
this.remainingTime = this.remainingTime / 1000;
if (this.remainingTime <= 0) {
this.SearchDate = moment();
this.searchEndDate = this.SearchDate.add(this.ElapsTime, "minutes");
this.TimerExpired.emit();
this.SubmitTest();
this.showQuestions();
}
else {
this.minutes = Math.floor(this.remainingTime / 60);
this.seconds = Math.floor(this.remainingTime - this.minutes * 60);
}
this.ref.markForCheck()
})

///

console.log(qstns)
this.questionList=qstns['default'];


}
ngOnDestroy(): void {
this.subscription.unsubscribe();
}
showQuestions(){
if(this.showindex<this.questionList.length)
this.showindex++
}
SubmitTest(){
swal("","Submitted Successfully. Please check your registered mail for score","success")
}
SubmitQuestion()
{
swal("","Submitted ","success")
}
}
