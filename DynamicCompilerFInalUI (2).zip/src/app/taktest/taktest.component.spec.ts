import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaktestComponent } from './taktest.component';

describe('TaktestComponent', () => {
  let component: TaktestComponent;
  let fixture: ComponentFixture<TaktestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaktestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaktestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
