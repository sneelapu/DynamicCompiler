import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MustMatch } from '../helpers/must-match.validators';
import swal from 'sweetalert';
import { Router } from '@angular/router';
import { NgbActiveModal, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { GetUserInfoService } from '../services/get-user-info.service';
import { first } from 'rxjs/operators';
import { NgbDateFRParserFormatt } from '../DateParser';
import { AngularFireStorage, AngularFireUploadTask } from 'angularfire2/storage';


import * as firebase from 'firebase/app';
import 'firebase/storage';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [NgbDateFRParserFormatt]
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  firstFormGroup: any;
  secondFormGroup: FormGroup;
  years: any = [];
  fileName: any = '';
  downloadURL: any;
  file: any;
  constructor(private cd: ChangeDetectorRef, private formBuilder: FormBuilder, private router: Router, private singup: GetUserInfoService, private dateparse: NgbDateFRParserFormatt, private storage: AngularFireStorage) {
    this.firstFormGroup = this.formBuilder.group({
      fname: ['', Validators.required],
      lname: ['', Validators.required],
      dob: ['', Validators.required],
      email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]],
      gender: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.pattern('[6-9]\\d{9}')]],

      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required, Validators.minLength(6)]]
    }, {
        validator: MustMatch('password', 'confirmPassword')

      });
    this.secondFormGroup = this.formBuilder.group({
      clname: ['', Validators.required],
      year: ['null', Validators.required],
      branch: ['null', Validators.required],
      skillset: ['', Validators.required],
      resume: ['null', Validators.required],
      percent: ['', Validators.required],
      sem: ['null']
    });
    this.firstFormGroup.reset()
    this.secondFormGroup.reset()
  }

  ngOnInit() {
    // alert(new Date().getFullYear())
    var today = new Date().getFullYear()
    for (let i = today - 4; i <= today; i++) {
      this.years.push(i)
    }
    console.log(this.years)
    //   this.registerForm = this.formBuilder.group({
    //     firstName: ['', Validators.required],
    //     lastName: ['', Validators.required],
    //     email: ['', [Validators.required, Validators.email]],
    //     password: ['', [Validators.required, Validators.minLength(6)]],
    //     confirmPassword: ['', Validators.required]
    // }, {
    //     validator: MustMatch('password', 'confirmPassword')
    // });

    // this.secondFormGroup.controls['resume'].setValue('')
  }
  //   _keyPress(event: any) {
  //     const pattern = /[0-9]/;
  //     let inputChar = String.fromCharCode(event.charCode);
  //     if (!pattern.test(inputChar)) {
  //         event.preventDefault();

  //     }
  // }

  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }

    //    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value))
  }
  dismiss() {
    // this.activeModal.dismiss();
  }
  SubmittedForm() {

    console.log(this.firstFormGroup.value);
    console.log(this.secondFormGroup.value);
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'];
    let fileMonth = monthNames[new Date().getMonth()];

    let fileYear = new Date().getUTCFullYear();
    console.log(this.file)

    var path = `test/${fileYear}/${fileMonth}/${this.fileName}`
    console.log(path)
    const fileRef = this.storage.ref(path);
    console.log(fileRef)
    const task = this.storage.ref(path).put(this.file);
console.log(task)
    const storageRef = firebase.storage().ref();
    const uploadTask = storageRef.child(`${path}/${this.fileName}`).put(this.file);
  




    uploadTask.on(firebase.storage.TaskEvent.STATE_CHANGED,
      (snapshot) => {

        const snap = snapshot as firebase.storage.UploadTaskSnapshot;
      },
      (error) => {
console.log(error)
      },
      () => {



        uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
          console.log('File available at', downloadURL);
          this.downloadURL = downloadURL
          let userdata = {
            "fname": this.firstFormGroup.value.fname,
            "lname": this.firstFormGroup.value.lname,
            "password": this.firstFormGroup.value.password,
            "passwordConf": this.firstFormGroup.value.confirmPassword,
            "email": this.firstFormGroup.value.email,
            "gender": this.firstFormGroup.value.gender,
            "dob": this.dateparse.format(this.firstFormGroup.value.dob),
            "graduationyear": this.secondFormGroup.value.year,
            "semister": this.secondFormGroup.value.sem,
            "stream": this.secondFormGroup.value.branch,
            "skills": this.secondFormGroup.value.skillset,
            "phone": this.firstFormGroup.value.mobile,
            "url": this.downloadURL,
            "filename": this.secondFormGroup.value.resume,
            "institute": this.secondFormGroup.value.clname,
            "percent": this.secondFormGroup.value.percent

          }
          console.log(userdata);

          this.singup.AddUser(userdata)

            .subscribe(
              data => {
                console.log(data)
                swal("", "Thank you, For your Interest.we have sent you the credntails to your registered Email .", "success").then((result) => {
                  this.router.navigate(['login'])
                })
              },
              error => {
                swal("", "Something went wrong.please, try again", "warning")

              });

        })
      })




  }
  uploadFile(event) {
    console.log(event.target.files[0])
    this.file = event.target.files[0]
    this.fileName = event.target.files[0].name
    console.log(this.file.name)

    this.secondFormGroup.controls['resume'].patchValue(this.file ? this.fileName : '', { emitModelToViewChange: true });

  }
}
