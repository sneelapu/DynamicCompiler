var express = require('express');
var router = express.Router();
var User = require('../model/user')
var Admin = require('../model/Admin')
var HR = require('../model/Hr')

var mongoose = require('mongoose')
var url = "mongodb+srv://Miracle123:Miracle@cluster0-g2cmv.mongodb.net/MyData?retryWrites=true&w=majority"
var bcrypt = require('bcrypt');
const config = require('../config.json');
const jwt = require('jsonwebtoken');
const { c, cpp, node, python, java } = require('compile-run');
const fs = require('fs');
var nodemailer = require('nodemailer');
var usercontrol = require('../controller/usercontroller')
var admincontrol = require('../controller/admincontroller')
/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

//Api for registering users
mongoose.connect(url,{
  keepAlive: true,
  useNewUrlParser: true,
  useCreateIndex: true,
  useFindAndModify: false
}, function (err, db) {
  if (err) throw err;
  // var dbo=db.db("test");
  else {
    console.log('connected to db')
  }
})
//For registering users
router.post('/Signup', function (req, res, next) {
  usercontrol.registernewUser(req, (response) => {
    console.log("response", response)
    if (response.status) {
      //responding back with suucess status code and response
      res.status('200');
      res.json(response);
    } else {
      //responding back with failed status code and response
      res.status('500');
      res.json(response);
    }
  })

})


// function getNextSequenceValue(sequenceName) {

//   console.log('ser', sequenceName)

//   // counter.findByIdAndUpdate({
//   //     query:{_id: sequenceName },
//   //     update: {$inc:{count:1}},
//   //     new:true
//   //  }).exec(function(err,respo)

//   //  {
//   //    if(err) throw err
//   //    console.log('final resapoms',respo)
//   //   return sequenceDocument.count;
//   //  })
//   var sequenceDocument = counter.findAndModify({
//     query: { _id: '5d40b1f31c9d44000040b60a' },
//     update: { $inc: { count: 1 } },
//     new: true
//   });
//   console.log(sequenceDocument)
// }

comparePassword = function (plainPass, hashword, callback) {
  bcrypt.compare(plainPass, hashword, function (err, isPasswordMatch) {
    return err == null ?
      callback(null, isPasswordMatch) :
      callback(err);
  });
};

//For getting all Registered Uers list
router.get('/Allusers', function (req, res, next) {
console.log(req.headers)
  if(req.headers.authorization){
  usercontrol.getUsersList(req.body, (response) => {
    if (response.status) {
      //responding back with suucess status code and response
      res.status('200');
      res.json(response);
    } else {
      //responding back with failed status code and response
      res.status('500');
      res.json(response);
    }
  })
}
else{
  res.json({'error':'Unauthorized Access'})
 }

});

//For getting users list with limit 
router.post('/UsersList', function (req, res, next) {
  console.log("test",req.headers.authorization)
  if(req.headers.authorization){
  usercontrol.UsersListlimit(req.body, (response) => {
    console.log(response)
    if (response.status) {
      //responding back with suucess status code and response
      res.status('200');
      res.json(response);
    } else {
      //responding back with failed status code and response
      res.status('500');
      res.json(response);
    }
  })
}
else{
  res.json({'error':'Unauthorized Access'})
}
});


//For getting a user deails with zcre NUmber
router.post('/user', function (req, res, next) {
  console.log(req.headers)
  if(req.headers['x-access-token']){
    usercontrol.getuserbyNumber(req.body, (response) => {
      if (response.status) {
        //responding back with suucess status code and response
        res.status('200');
        res.json(response);
      } else {
        //responding back with failed status code and response
        res.status('500');
        res.json(response);
      }
    })
  }
 else{
  res.json({'error':'Unauthorized Access'})
 }


})

//Login APi
router.post('/login', function (req, res, next) {

  console.log(req.body)
  var number = req.body.username
  var password = req.body.password
  Admin.find({ Username: number }).select().exec(function (err, admins) {
    console.log('admin', admins)
    if (admins.length == 0) {
      //res.send({ 'success': 'User Not found' })
      HR.find({ Username: number }).select()

        .exec(function (err, hrdata) {
          console.log('HRdata', hrdata)
          if (hrdata.length == 0) {
            User.find({ email: number }).select().exec(function (err, resp) {
              console.log('user', resp)
              if (resp.length == 0) {
                res.send({ 'success': 'User Not found' })
              }
              else {
                console.log('Password', resp[0].password)
                comparePassword(password, resp[0].password, function (err, result) {
                  console.log('Password chc', result)
                  if (result == true) {
                 
                    const user = {
                      "email": resp[0].email,
                      "name":resp[0].fname
                  }
                  // do the database authentication here, with user name and password combination.
                  const token = jwt.sign(user, config.secret, { expiresIn: config.tokenLife})
                  const refreshToken = jwt.sign(user, config.refreshTokenSecret, { expiresIn: config.refreshTokenLife})
                    // return the information including token as JSON
                    res.json({
                      success: true,
                      message:'you have successfully logged in',
                      token: token,
                      email: user.email,
                      data: resp
                    });

                  }
                  else {
                    res.send({ 'success': 'Invalid Username or Password' })
                  }
                })

              }



            })
          }
          else {
            console.log('hrrole')
            // comparePassword(password, hrdata[0].Password, function (err, result) {
            //   console.log('Password chc', result)
            //   if (result == true) {
            //     var token = jwt.sign(payload, 'secret', {
            //       expiresIn: 1440
            //     });
            if (password == hrdata[0].Password) {
              const user = {
                "email": hrdata[0].email,
                "name":hrdata[0].fname
            }
            // do the database authentication here, with user name and password combination.
            const token = jwt.sign(user, config.secret, { expiresIn: config.tokenLife})
            const refreshToken = jwt.sign(user, config.refreshTokenSecret, { expiresIn: config.refreshTokenLife})
              // return the information including token as JSON
              res.json({
                success: true,
                message: 'you have successfully logged in',
                token: token,
                email: user.email,
                data: hrdata
              });

              

              // return the information including token as JSON


            }
            else {
              res.send({ 'success': 'Invalid Username or Password' })
            }

          }

        })
    }
    else {
      if (password == admins[0].Password) {
        const user = {
          "email": admins[0].email,
          "name":admins[0].fname
      }
      // do the database authentication here, with user name and password combination.
      const token = jwt.sign(user, config.secret, { expiresIn: config.tokenLife})
      const refreshToken = jwt.sign(user, config.refreshTokenSecret, { expiresIn: config.refreshTokenLife})
        // return the information including token as JSON
        res.json({
          success: true,
          message: 'you have successfully logged in',
          token: token,
        
          data: admins
        });


        // return the information including token as JSON


      }
      else {
        res.send({ 'success': 'Invalid Username or Password' })
      }

    }

  })


})

function comparePassword(pass, hashcode, callback) {
  console.log('Iside funv', pass)
  var pass = pass
  var hashcode = hashcode
  // return new Promise(function(resolve, reject) {
  bcrypt.compare(pass, hashcode, function (err, response) {
    if (err) throw err
    callback(err, response);

  })

}
function random(low, high) {
  return randomC(4) / Math.pow(2, 4 * 8 - 1) * (high - low) + low;
}

//For scheduling test
router.post('/scheduleTests', function (req, res, next) {
  if(req.headers.authorization){
  console.log(req.body)
  console.log(Date.now() + Math.random());
  let scheduledata = {
    "_id": Date.now() + Math.random(),
    "screeningDate": req.body.screeningDate,
    "starttime": req.body.starttime,
    "endtime": req.body.endtime,
    "language": req.body.language,
    "Questions": req.body.Questions,
    "Duration": req.body.Duration,
    "crefrom": req.body.crefrom,
    "creto": req.body.creto,
    "createdby": req.body.createdby,
    "score": 0,
    "status": ""
  }
  let scheduledata1 = {
    "_id": Date.now() + Math.random(),
    "screeningDate": req.body.screeningDate,
    "starttime": req.body.starttime,
    "endtime": req.body.endtime,
    "language": req.body.language,
    "Questions": req.body.Questions,
    "Duration": req.body.Duration,
    "crefrom": req.body.crefrom,
    "creto": req.body.creto,
    "createdby": req.body.createdby,
    // "score": 0,
    // "status": ""
  }
  HR.findOneAndUpdate({ Username: req.body.createdby }, { $push: { scheduledTests: [req.body] } }, { new: true }).exec(function (err, resp) {
    if (err) {
      res.send({ 'error': err })
    }
    else {


      User.update({ number: { $gte: req.body.crefrom, $lte: req.body.creto } }, { $set: { screenindDetails: [scheduledata1] } }, { multi: true }).exec(function (err1, response) {

        console.log(res)
        if (err1) {
          res.send({ 'error': err1 })
        }

        else {
          console.log(response)
          var mailOptions = {
            from: 'nnoon.solutions@gmail.com',
            //to: req.query.usermail,
            to: req.body.email,
            subject: 'Screeing Test for software Trainee',
            text: 'Hello' + "" + personInfo.fname + " " + personInfo.lname,
            html: `<html lang="en">
              <head>
                <title>Bootstrap Example</title>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
              </head>
              <body>
              
              
              <p>You have been invited to attend  the Miracle Drive . Please check the screening details below</p>
              
            
                <div class="row">
                  <div class="col-1" style="font-weight: 500;">Date :    `+ req.body.screeningDate + `</div>
                </div>
              <div class="row">
                  <div class="col-1" style="font-weight: 500;">Time :    `+ req.body.starttime + ` to ` + req.body.endtime + `</div>
                </div>
              
              </body>
              </html>`


          };

          transporter.sendMail(mailOptions, function (error, data) {
            if (error) {
              console.log(error);
            } else {
              console.log('Email sent: ' + data.response);


              res.send({ 'success': 'updated Sucesfully' })


              //  res.send({response:'mail sent sucessfully'})
            }
          });

        }

      })

    }

  })



  }


else{
  res.json({'error':'Un authorized Access'})
}
})
//uplading new queations by admin
router.post('/createTests', function (req, res, next) {
  console.log(req.body)
  if(req.headers.authorization){
  admincontrol.uploadTests(req, (response) => {
    if (response.status) {
      //responding back with suucess status code and response
      res.status('200');
      res.json(response);
    } else {
      //responding back with failed status code and response
      res.status('500');
      res.json(response);
    }
  })
}
else{
  res.json({'error':'Un authorized Access'})
}
})
router.post("/compilecode", function (err, res) {


})

//updating user score
router.put("/userscore", function (req, res, next) {

  usercontrol.updateUserscore(req, (response) => {
    if (response.status) {
      //responding back with suucess status code and response
      res.status('200');
      res.json(response);
    } else {
      //responding back with failed status code and response
      res.status('500');
      res.json(response);
    }
  })
})


module.exports = router;
