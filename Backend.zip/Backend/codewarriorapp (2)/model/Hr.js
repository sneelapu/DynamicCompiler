var mongoose = require('mongoose');
const AutoIncrement = require('mongoose-auto-increment');
var Schema = mongoose.Schema; // <-- EDIT: missing in the original post


 

var HRSchema = new Schema({
    Username:String,
    Password:String,
    role:String,
    scheduledTests:Array
})
var HR=mongoose.model("hrdetails", HRSchema);
module.exports=HR