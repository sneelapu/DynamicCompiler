var mongoose = require('mongoose');

var Schema = mongoose.Schema; // <-- EDIT: missing in the original post


 

var AdminSchema = new Schema({
    Username:String,
    Password:String,
    role:String,
    Tests:Array
})
var Admin=mongoose.model("admins", AdminSchema);
module.exports = Admin;

