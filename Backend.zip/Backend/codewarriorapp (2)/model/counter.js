var mongoose = require('mongoose');
const AutoIncrement = require('mongoose-auto-increment');
var Schema = mongoose.Schema; // <-- EDIT: missing in the original post


 

var counterschema = new Schema({
    count:00000,
    
    
})
var count=mongoose.model("counts", counterschema);
module.exports=count