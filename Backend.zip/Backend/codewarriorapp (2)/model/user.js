var mongoose = require('mongoose');
const AutoIncrement = require('mongoose-auto-increment');
const AutoIncrement1 = require('mongoose-sequence')(mongoose);
var Schema = mongoose.Schema; // <-- EDIT: missing in the original post

mongoose.connect("mongodb+srv://Miracle123:Miracle@cluster0-g2cmv.mongodb.net/MyData?retryWrites=true&w=majority");

const db = mongoose.connection;

AutoIncrement.initialize(db);
var Userschema = new Schema({
  
    CRENumber: {type: String},
    fname:{
        type: String,
        required: [true, 'firstName is Required'],
    },
    lname:{
        type: String,
        required: [true, 'lastName is Required'],
    },
    password:{
        type: String,
        required: [true, 'password is Required'],
    },
    cpassword:{
        type: String,
        required: [true, 'Confirm Password is Required'],
    },
    email:{
        
            type: String,
            required: [true, 'Email is Required'],
            unique:true
        
        
    },
    gender:{
        type: String,
        required: [true, 'Gender is Required'],
    },
    dob:{
        type: String,
        required: [true, 'Date of Birth  is Required'],
    },
    graduatedyear:{
        type:Number,
        required: [true, 'Graduation Year is Required'],
    },
    semister:{
type:Number,

},
number:{
    type:Number
},
    branch:{
        type: String,
        required: [true, 'Branch is Required'],
    },
    skillset:{
        type: String,
        required: [true, 'Skill Set is Required'],
    },
    resume:{
        type: String,
        required: [true, 'Resume is Required'],
    },
      resitereddate: { type: Date, default: Date.now },
    screenindDetails:Array,
     role:{
        type: String,
        required: [true, 'Role is Required'],
    },
    contactno:{
        type:Number,
        required: [true, 'Mobilenumber is Required'],

    },
    institute:{
        type:String,
        required: [true, 'College is Required'],
    },
    percent:{
        type:String,
        required: [true, 'College is Required'],
    },
   filename:{
       type:String,
       required:[true,'filename is required']
   }

});


 var User=mongoose.model("users", Userschema);
//  var counterschema = new Schema({
//     count:0,
    
    
// })
// var counter=mongoose.model("counts", counterschema);
//  Userschema.pre('save', function(next) {
//     var doc = this;
  
// });

module.exports = User;
