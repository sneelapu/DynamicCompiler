var admin=require('../model/Admin')


//for adding new questions

uploadTests=(req,callback)=>{
 
admin.findOneAndUpdate({ Username: req.body.createdby }, { $push: { Tests: req.body} }).exec(function (err, resp) {
    if (err) {
      callback({ status:false,'error': err })
    }
    else {
      console.log("resp",resp)
      if (resp) {

        callback({ status:true,'success': 'Uploaded test Sucesfully' })
      }

    }
    // console.log(resp)
  })
}
module.exports={
    uploadTests:uploadTests
}