var User = require('../model/user')
var counter = require('../model/counter')
var bcrypt = require('bcrypt');
var nodemailer=require('nodemailer')


//for getting all the registered users
getUsersList = (request, callback) => {

    var signupquery = User.find({}).select()
    .sort('number');
  signupquery.exec(function (err, data) {
    console.log(data)
    if (err) {
      console.log(err);
     //response.status(500).send(err); 
     callback({
        'status': false,
        'data': err
    });
    }
    else {
   //   console.log('Success', res);
      callback({
        status:true,
        count: data.length,
        UsersList: data
      })
    }
  })
}
//function for getting all the regsitered userslist with serverside pagination
UsersListlimit = (request, callback) => {
    console.log(request.page)
    var perPage = 5
    var page = request.page || 1
  
    User
      .find({})
      .skip((perPage * page) - perPage)
      .limit(perPage)
      .exec(function (err, users) {
        console.log(err)
        console.log(users)
        User.countDocuments().exec(function (error, count) {
          console.log(error)
          console.log(count)
          if (error) 
          callback({
            status:false,error:error
          })
          else{
            callback({
              status:true,
              UsersList: users,
              current: page,
              count: count,
              pages: Math.ceil(count / perPage)
            })
          }
         
        })
      })
}

//for adding a new user
registernewUser=(req,callback)=>{
  
    var personInfo = req.body;
    var email1 = personInfo.email
    console.log(personInfo)
  console.log(personInfo.password)
  console.log(personInfo.fname)
  console.log(personInfo.passwordConf)
    if (!personInfo.email || !personInfo.fname || !personInfo.password || !personInfo.passwordConf) {
     callback({
        error: "something went wrong"
      })
    } else {
      if (personInfo.password == personInfo.passwordConf) {
  
        var signupquery = User.findOne({ email1 }).select('email fname');
        signupquery.exec(function (err, data) {
          if (data) {
            //  console.log('Success');
            callback({
              status: res.status,
  
              success: "Already"
            })
          }
  
          else {
  
         
             
              bcrypt.hash(req.body.password, 10, function (err, hash) {
                if (err)
                  console.log(err)
                else {
                  ///   console.log(hash)
                  var password = hash
                  bcrypt.hash(req.body.passwordConf, 10, function (err, hash1) {
                    if (err) {
                        callback({
                            'status': false,
                            'data': err
                        });
                    }
                    else {
                        counter.findByIdAndUpdate({ _id: '5d40b1f31c9d44000040b60a' }, { $inc: { count: 1 } }, function (error, counter1) {
                            
                          
                        console.log('count',counter1)
                      var cpassword = hash1
                      var newUser = new User({
                        CRENumber: 'CRE' + '000' + '' + counter1.count,
                        number: counter1.count,
                        fname: personInfo.fname,
                        lname: personInfo.lname,
                        password: password,
                        cpassword: cpassword,
                        email: personInfo.email,
                        gender: personInfo.gender,
                        dob: personInfo.dob,
                        graduatedyear: personInfo.graduationyear,
                        semister: personInfo.semister,
                        branch: personInfo.stream,
                        skillset: personInfo.skills,
                        resume: personInfo.url,
                        contactno:personInfo.phone,
                        institute:personInfo.institute,
                        percent:personInfo.percent,
                        filename:personInfo.filename,
                        role: "user"
  
  
                      })
                   
                      newUser.save(function (err, Person) {
  
  
                        if (err) {
                            console.log('errror',err)
                            counter.findByIdAndUpdate({ _id: '5d40b1f31c9d44000040b60a' }, { $inc: { count: -1 } }, function (error, counter3) {
                                callback({
                                    'status': false,
                                    'data': err
                                });
                              })
                            
                        }
  
                        else {
                          console.log('Success',Person.fname);
                        
                     
                        var transporter =  nodemailer.createTransport({
                            host: 'smtp.miraclesoft.com',
                            port: 587,
                            secure: false,
                            auth: {
                                user: 'vbezawada@miraclesoft.com',
                                pass: 'Miracle#1'
                            }
                        });
                          var mailOptions = {
                            from: 'vbezawada@miraclesoft.com',
                            //to: req.query.usermail,
                            to:Person.email,
                            subject: 'Screeing Test for software Trainee',
                            text: '',
                            html: `<html lang="en">
                            <head>
                              <title>Bootstrap Example</title>
                              <meta charset="utf-8">
                              <meta name="viewport" content="width=device-width, initial-scale=1">
                              <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
                              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
                              <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
                              <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
                            </head>
                            <body>
                            
                            <p>Hello`+" "+Person.fname +`,</p>
                            <p>Thank you for registering with us.Here are your registration details</p>
                              <div class="row">
                                <div class="col-1" style="font-weight: 500;">CRE Number :    `+ Person.CRENumber + `</div>
                            
                              </div>
                           
                            
                            </body>
                            </html>`
                    
  
                          };
  
                          transporter.sendMail(mailOptions, function (error, data) {
                            if (error) {
                              console.log(error);
                              callback({
                                  status:false,
                                  error:error
                              })
                            } else {
                              console.log('Email sent: ' + data.response);
                              callback({
                                status: true,
  
                                success: "you have successsFully registered with us"
                              })
  
                            //  res.send({response:'mail sent sucessfully'})
                            }
                          });
  
                        }
  
                      })
  
                    
                  })
                }
              })
  
  
  
              // next();
            
  
          }
        })
        }
})
      }
}
} 

//getting a user data by crenumber

getuserbyNumber=(req,callback)=>{
    var number = req.body.crenumber
    var signupquery = User.find({ CRENumber: number }).select('email fname');
    signupquery.exec(function (err, data) {
      if (err) {
        console.log(err);
        callback({
            status:false,
            error:err
        })
      }
      else {
        console.log('Success');
        callback({
         status: true,
  
          Userdata: data
        })
      }
  
  
    })
}

//updating the user score once the test is done
updateUserscore=(req,callback)=>{
    User.find( { CRENumber: req.body.number }).exec(function(err,resp){
        if(err){
            callback({
                status:false,
                error:err
            })
        }
        else{
          console.log('resp',resp[0].screenindDetails)
         
          var updatscreeningdata={
            "screeningDate":resp[0].screenindDetails[0].screeningDate,
            "starttime":resp[0].screenindDetails[0].starttime,
            "endtime":resp[0].screenindDetails[0].endtime,
            "language":resp[0].screenindDetails[0].language,
            "Questions":resp[0].screenindDetails[0].Questions,
            "Duration":resp[0].screenindDetails[0].Duration,
            "createdby":resp[0].screenindDetails[0].createdby,
            "score":req.body.score,
           "status":""
           
          }
          console.log(updatscreeningdata)
          User.findOneAndUpdate(
            { CRENumber: req.body.number },
            { $set: { "screenindDetails":updatscreeningdata} }, 
            // { $addToSet: { screenindDetails: { $each: [ {score:req.body.score} ] } } }
            function (error, success) {
              if (error) {
                callback({
                    status:false,
                    error:error
                })
              } else {
                var transporter =  nodemailer.createTransport({
                    host: 'smtp.miraclesoft.com',
                    port: 587,
                    secure: false,
                    auth: {
                        user: 'vbezawada@miraclesoft.com',
                        pass: 'Miracle#1'
                    }
                });
                  var mailOptions = {
                    from: 'vbezawada@miraclesoft.com',
                    //to: req.query.usermail,
                    to:success.email,
                    subject: 'Screeing Test for software Trainee',
                    text: '',
                    html: `<html lang="en">
                    <head>
                      <title>Bootstrap Example</title>
                      <meta charset="utf-8">
                      <meta name="viewport" content="width=device-width, initial-scale=1">
                      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
                      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
                      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
                      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
                    </head>
                    <body>
                    
                    <p>Hello`+Person.fname +`,</p>
                    <p>Here are the result of the test that you have attended on `+resp[0].screenindDetails[0].screeningDate+`</p>
                      <div class="row">
                        <div class="col-1" style="font-weight: 500;">Language:    `+ resp[0].screenindDetails[0].language + `</div>
                    
                      </div>
                      <div class="row">
                      <div class="col-1" style="font-weight: 500;">Score:    `+ req.body.score + `</div>
                  
                    </div>
                   
                    
                    </body>
                    </html>`
            

                  };

                  transporter.sendMail(mailOptions, function (error, data) {
                    if (error) {
                      console.log(error);
                      callback({
                          status:false,
                          error:error
                      })
                    } else {
                      console.log('Email sent: ' + data.response);
                      callback({
                        status:false,
                        success:'updated score succesfully'
                    })

                    //  res.send({response:'mail sent sucessfully'})
                    }
                  });
              
             
              }
            });
        
        }
      })
}

//analayzing the program
compileprogram=(req,callback)=>{
    if(req.body.language=="C"){
        var fileName="ctest.c"
        }
        else if(req.body.language=="C++"){
            console.log("Inside C++ loop")
            fileName="cpptest.cpp"
        }
        else if(req.body.language=="Java"){
            fileName="test.java"
        console.log("Inside Java  loop")}
        else if(req.body.language=="Python"){
            fileName="pythontest.py"
        }
        console.log("fileName to be saved with Esternson",fileName)
       fs.writeFile('temp'+'/'+fileName, req.body.code, function(err) {
        if(err) {
            return console.log(err);
        }
       
        else{
             console.log("The file was saved!");
            if(req.body.language=="C"){
            console.log("Inside Cloop")
            c.runFile('temp'+'/'+fileName,{ stdin:req.body.input} ,(err, result) => {
        if(err){
            console.log(err);
        }
        else{
            console.log(result);
        }
    });
        
        }
        else if(req.body.language=="C++"){
            console.log("Inside C++ loop")
            cpp.runFile('temp'+'/'+fileName,{ stdin:'3\n2 '} ,(err, result) => {
        if(err){
            console.log(err);
        }
        else{
            console.log(result);
        }
    });
        
        }
        else if(req.body.language=="Java"){
            console.log("Inside Java  loop")
        
    java.runFile('temp'+'/'+fileName,
    {stdin:req.body.input}, 
    (err,result)=>{
        if(err)
            console.log(err)
        else{
            
            var exprsult=[
            {
                result:"Sum of two numbers is 14"
            },
            {
                result:"result is 14"
            },
            {
                result:"14"
            },{
                result:"'Sum of these numbers: 14\r\n"
            }
            ]
            exprsult.forEach(element=>{
                console.log(element)
                if(element.result.includes(result.stdout)){
                    console.log("Inside")
                }
            })
        }
    });
     
        }
        else if(req.body.language=="Python"){
        console.log("Inside Pyhton loop")	
        python.runFile('temp'+'/'+fileName,{
      
    },(err,result)=>{
        
    });
        }
        
        }
        
    
     }); 
}
module.exports={
    getUsersList:getUsersList,
    UsersListlimit:UsersListlimit,
    registernewUser:registernewUser,
    getuserbyNumber:getuserbyNumber,
    updateUserscore:updateUserscore
}